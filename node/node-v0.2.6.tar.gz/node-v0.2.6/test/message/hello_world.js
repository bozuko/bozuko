common = require("../common");
assert = common.assert

console.log('hello world');

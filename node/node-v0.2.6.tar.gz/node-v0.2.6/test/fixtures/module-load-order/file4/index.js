exports.file4 = 'file4/index.js';

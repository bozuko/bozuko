Bozuko.view.Game = Ext.extend( Ext.Panel, {
    
    layout: 'fit',
    
    initComponent : function(){
        Bozuko.view.Game.superclass.initComponent.call(this);
    },
    
    loadGame : function(game, place, coords){
        console.log(game,place,coords);
        Ext.Ajax.request({
            method:'get',
            url: '/place/'+place.id+'/game',
            params:{
                'lat':coords[0],
                'lng':coords[1]
            },
            callback : function(){
                this.game = game;
                this.place = place;
                if( this.gameObject ){
                    this.gameObject.reset();
                }
                else{
                    this.gameObject = new Bozuko.game.Dice({
                        fps: 13,      // Frames per second
                        spf: 1/13,   // Seconds per frame
                        el: this.getEl().down('.x-panel-body')
                    });
                    this.gameObject.on('win', this.onWin, this);
                    this.gameObject.on('lose', this.onLose, this);
                }
            },
            scope: this
        });
    },
    
    getPlace : function(){
        return this.place;
    },
    
    onWin : function(){
        Ext.Msg.alert('You won!', this.game.prize);
    },
    
    onLose : function(){
        Ext.Msg.alert('Sorry, you lose!', "Bummer... better luck next time buddy.");
    }
    
});
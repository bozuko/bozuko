Ext.regModel('Place', {
    fields: [
        {name: 'name'},
        {name: 'category'},
        {name: 'location'},
        {name: 'id'},
        {name: 'registered'},
        {name: 'games'}
    ]
});

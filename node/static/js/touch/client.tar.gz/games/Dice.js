Ext.ns('Bozuko.game');

Bozuko.game.Dice = Ext.extend( Ext.util.Observable, {
    
    imageDir : '/images/games/dice',
    
    constructor : function(config){
        Ext.apply(this, config);
        this.totalImgCt = 3;
        this.imgLoadCt = 0;
        this.bg = new Image();
        this.bg.src = this.imageDir+"/felt.jpg";
        Ext.EventManager.on(this.bg, 'load', this.onImgLoad, this);
        this.diceBounce = .8;
        this.wallBounce = .8;
        this.drawTimer = null;
        this.physics = new Physics();
        this.state = 'init';
        
        this.events = {
            'finish'    :true,
            'win'       :true,
            'lose'      :true
        };
        
        Bozuko.game.Dice.superclass.constructor.call(this);
        
        if( this.el ){
            this.render(this.el);
        }
    },
    
    reset : function(){
        this.state = 'init';
        this.loopDelegate = Ext.createDelegate(this.loop, this);
        this.drawTimer = setInterval(this.loopDelegate, this.spf*1000);
    },
    
    makeWall : function(x1,y1,x2,y2){
        return new Wall(new Polygon([new Vector(x1,y1), new Vector(x2,y2)]));
    },
    
    onImgLoad : function(){
        this.imgLoadCt++;
    },
    
    render : function(el){
        this.el = Ext.get(el);
        var size = this.el.getSize();
        this.width = size.width;
        this.height = size.height;
        this.canvas = this.el.createChild({
            tag: 'canvas',
            width: this.width,
            height: this.height
        });
        // give a second for the panel to slide in...
        Ext.EventManager.on(this.canvas,'click',this.play, this);
        this.ctx = this.canvas.dom.getContext('2d');
        this.ctx.globalAlpha = 1;
        this.dice1 = new Sprite(this.imageDir+"/dice-all-new", 6, 100, this.height/2-75, this.ctx, this.onImgLoad, this);
        this.dice2 = new Sprite(this.imageDir+"/dice-all-new", 6, 220, this.height/2-75, this.ctx, this.onImgLoad, this);
        this.walls = [
            this.makeWall(0, 0, 0, this.height), //left
            this.makeWall(0, 0, this.width, 0), //top
            this.makeWall(this.width, 0, this.width, this.height), //right
            this.makeWall(0, this.height, this.width, this.height)
        ]; // bottom
        
        this.loopDelegate = Ext.createDelegate(this.loop, this);
        this.drawTimer = setInterval(this.loopDelegate, this.spf*1000);
    },
    
    initDice :function() {
    //	this.dice1.vel = new Vector(-7, 20);
        this.dice1.vel = new Vector(0, 0);
        this.dice1.angVel = 1;
    //	this.dice2.vel = new Vector(5, -20);
        this.dice2.vel = new Vector(0, 0);
        this.dice2.angVel = -1;
    },

    play : function() {
        
        if (this.state != 'rolling') {
            this.state = 'rolling';
            Ext.defer(this.stop, 2500, this);
        }
	},

    loop : function() {
        var ctx = this.ctx;
        var dice1 = this.dice1;
        var dice2 = this.dice2;
        var i;
        var wall;
        
        ctx.clearRect(0, 0, this.width, this.height);
        ctx.drawImage(this.bg, 0, 0, this.width, this.height);
        
        if (this.state === 'init') {
            if (this.imgLoadCt === this.totalImgCt) {
                this.initDice();
                this.state = 'loaded';
                Ext.Msg.alert('Tap to Roll', "Roll 7, 11, or Doubles to win!");
            }
        } else if (this.state === 'loaded') {
            dice1.frameIndex = 0;
            dice2.frameIndex = 0;
            dice1.draw();
            dice2.draw();
        } else if (this.state === 'rolling') {
            dice1.frameIndex = Math.floor(Math.random() * dice1.numFrames);
            dice2.frameIndex = Math.floor(Math.random() * dice2.numFrames);
            this.physics.move([dice1, dice2]);
            this.physics.collide(dice1, dice2, this.diceBounce);
            for (i = 0; i < this.walls.length; i++) {
                wall = this.walls[i];
                this.physics.collide(dice1, wall, this.wallBounce);
                this.physics.collide(dice2, wall, this.wallBounce);
            }
            dice1.draw();
            dice2.draw();
        } else if (this.state === 'stopped') {
            clearInterval(this.drawTimer);
            this.drawTimer = null;
            dice1.draw();
            dice2.draw();
            var sum = this.dice1.frameIndex+1 + this.dice2.frameIndex+1;
            var win = (this.dice1.frameIndex === this.dice2.frameIndex) || (sum === 7) || (sum === 11);
            this.fireEvent('finish', win);
            this.fireEvent(win?'win':'lose', this);
        } 
    },

    stop : function() {
        this.state = 'stopped';
    }
});